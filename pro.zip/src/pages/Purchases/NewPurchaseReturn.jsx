// ======================================
// New Purchase Return - إرجاع فاتورة مشتريات
// ======================================

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../../context/DataContext';
import { useNotification } from '../../context/NotificationContext';
import { useSystemSettings } from '../../hooks/useSystemSettings';
import { FaSave, FaArrowLeft, FaUndo } from 'react-icons/fa';
import { formatCurrency } from '../../utils/currencyUtils';

const NewPurchaseReturn = () => {
  const { invoiceId } = useParams();
  const navigate = useNavigate();
  const { purchaseInvoices, products, suppliers, addPurchaseReturn, purchaseReturns } = useData();
  const { showSuccess, showError } = useNotification();
  const { currency: currentCurrency } = useSystemSettings();

  const [invoice, setInvoice] = useState(null);
  const [returnItems, setReturnItems] = useState([]);
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    // تحميل الفاتورة
    const foundInvoice = purchaseInvoices.find(inv => inv.id === parseInt(invoiceId));
    if (!foundInvoice) {
      showError('الفاتورة غير موجودة');
      navigate('/purchases/manage');
      return;
    }
    
    setInvoice(foundInvoice);
    
    // حساب الكميات المرتجعة مسبقاً لكل منتج
    const itemsWithReturnInfo = foundInvoice.items.map(item => {
      const previousReturns = purchaseReturns.filter(ret => 
        ret.invoiceId === foundInvoice.id && ret.status !== 'cancelled'
      );
      
      let totalReturnedQty = 0;
      previousReturns.forEach(ret => {
        const retItem = ret.items.find(i => i.productId === item.productId);
        if (retItem) {
          totalReturnedQty += (retItem.quantity || 0) + (retItem.subQuantity || 0);
        }
      });
      
      const originalQty = (item.quantity || 0) + (item.subQuantity || 0);
      const availableQty = originalQty - totalReturnedQty;
      
      // الحصول على اسم المنتج من قائمة المنتجات
      const product = products.find(p => p.id === parseInt(item.productId));
      
      return {
        productId: item.productId,
        productName: product?.name || item.productName || 'غير محدد',
        originalQuantity: item.quantity || 0,
        originalSubQuantity: item.subQuantity || 0,
        originalPrice: item.price || 0,
        originalSubPrice: item.subPrice || 0,
        returnedQty: totalReturnedQty,
        availableQty: availableQty,
        returnQuantity: 0,
        returnSubQuantity: 0,
        selected: false
      };
    });
    
    setReturnItems(itemsWithReturnInfo);
  }, [invoiceId, purchaseInvoices, purchaseReturns, navigate, showError]);

  const handleItemSelect = (index) => {
    const updated = [...returnItems];
    updated[index].selected = !updated[index].selected;
    
    // إذا تم إلغاء التحديد، إعادة تعيين الكميات
    if (!updated[index].selected) {
      updated[index].returnQuantity = 0;
      updated[index].returnSubQuantity = 0;
    }
    
    setReturnItems(updated);
  };

  const handleQuantityChange = (index, field, value) => {
    const updated = [...returnItems];
    const item = updated[index];
    
    updated[index][field] = Math.max(0, parseInt(value) || 0);
    
    // التحقق من عدم تجاوز الكمية المتاحة
    const totalReturn = updated[index].returnQuantity + updated[index].returnSubQuantity;
    if (totalReturn > item.availableQty) {
      showError(`الكمية المرتجعة تتجاوز الكمية المتاحة (${item.availableQty})`);
      updated[index][field] = 0;
    }
    
    setReturnItems(updated);
  };

  const calculateTotalReturn = () => {
    return returnItems.reduce((total, item) => {
      if (item.selected) {
        const mainAmount = item.returnQuantity * item.originalPrice;
        const subAmount = item.returnSubQuantity * item.originalSubPrice;
        return total + mainAmount + subAmount;
      }
      return total;
    }, 0);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // التحقق من وجود منتجات محددة
    const selectedItems = returnItems.filter(item => item.selected);
    if (selectedItems.length === 0) {
      showError('يرجى اختيار منتج واحد على الأقل للإرجاع');
      return;
    }

    // التحقق من الكميات
    const hasInvalidQuantity = selectedItems.some(item => 
      (item.returnQuantity + item.returnSubQuantity) === 0
    );
    
    if (hasInvalidQuantity) {
      showError('يرجى إدخال كمية صحيحة للمنتجات المحددة');
      return;
    }

    // التحقق من سبب الإرجاع
    if (!reason.trim()) {
      showError('يرجى إدخال سبب الإرجاع');
      return;
    }

    try {
      // إعداد بيانات الإرجاع
      const returnData = {
        invoiceId: invoice.id,
        items: selectedItems.map(item => ({
          productId: item.productId,
          quantity: item.returnQuantity,
          subQuantity: item.returnSubQuantity
        })),
        reason,
        notes
      };

      addPurchaseReturn(returnData);
      showSuccess('تم إرجاع المنتجات بنجاح');
      navigate('/purchases/returns');
    } catch (error) {
      showError(error.message || 'حدث خطأ في عملية الإرجاع');
    }
  };

  if (!invoice) {
    return (
      <div className="max-w-7xl mx-auto p-4">
        <div className="text-center py-8">
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  const supplier = suppliers.find(s => s.id === parseInt(invoice.supplierId));

  return (
    <div className="max-w-7xl mx-auto p-4">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800">إرجاع فاتورة مشتريات</h2>
          <p className="text-sm text-gray-600">فاتورة رقم #{invoice.id}</p>
        </div>
        <button
          onClick={() => navigate('/purchases/manage')}
          className="flex items-center gap-2 bg-gray-600 hover:bg-gray-700 text-white px-3 py-2 rounded-lg transition-colors"
        >
          <FaArrowLeft /> رجوع
        </button>
      </div>

      {/* معلومات الفاتورة الأصلية */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-4">
        <h3 className="text-sm font-bold text-gray-800 mb-3">معلومات الفاتورة الأصلية</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-blue-50 p-3 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">المورد</p>
            <p className="font-semibold text-sm">{supplier?.name || 'غير محدد'}</p>
          </div>
          <div className="bg-green-50 p-3 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">التاريخ</p>
            <p className="font-semibold text-sm">
              {new Date(invoice.date).toLocaleDateString('ar-EG')}
            </p>
          </div>
          <div className="bg-yellow-50 p-3 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">نوع الدفع</p>
            <p className="font-semibold text-sm">
              {invoice.paymentType === 'cash' ? 'نقدي' : invoice.paymentType === 'deferred' ? 'آجل' : 'جزئي'}
            </p>
          </div>
          <div className="bg-purple-50 p-3 rounded-lg">
            <p className="text-xs text-gray-600 mb-1">المجموع الكلي</p>
            <p className="font-bold text-lg text-purple-600">{formatCurrency(invoice.total, currentCurrency)}</p>
          </div>
        </div>
      </div>

      {/* نموذج الإرجاع */}
      <form onSubmit={handleSubmit}>
        {/* جدول المنتجات */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-4">
          <h3 className="text-sm font-bold text-gray-800 mb-3">المنتجات المراد إرجاعها</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-gray-100 border-b">
                  <th className="px-3 py-2 text-center text-xs font-semibold text-gray-700 w-8">
                    <input
                      type="checkbox"
                      onChange={(e) => {
                        const updated = returnItems.map(item => ({
                          ...item,
                          selected: e.target.checked && item.availableQty > 0
                        }));
                        setReturnItems(updated);
                      }}
                      className="rounded"
                    />
                  </th>
                  <th className="px-3 py-2 text-right text-xs font-semibold text-gray-700">المنتج</th>
                  <th className="px-3 py-2 text-center text-xs font-semibold text-gray-700">الكمية الأصلية</th>
                  <th className="px-3 py-2 text-center text-xs font-semibold text-gray-700">المرتجع سابقاً</th>
                  <th className="px-3 py-2 text-center text-xs font-semibold text-gray-700">المتاح</th>
                  <th className="px-3 py-2 text-center text-xs font-semibold text-gray-700">كمية الإرجاع</th>
                  <th className="px-3 py-2 text-center text-xs font-semibold text-gray-700">المبلغ المرتجع</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {returnItems.map((item, index) => {
                  const product = products.find(p => p.id === parseInt(item.productId));
                  const returnAmount = item.returnQuantity * item.originalPrice + 
                                      item.returnSubQuantity * item.originalSubPrice;
                  const isDisabled = item.availableQty === 0;
                  
                  return (
                    <tr key={index} className={`hover:bg-gray-50 ${isDisabled ? 'opacity-50' : ''}`}>
                      <td className="px-3 py-2 text-center">
                        <input
                          type="checkbox"
                          checked={item.selected}
                          onChange={() => handleItemSelect(index)}
                          disabled={isDisabled}
                          className="rounded"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <div className="font-medium">{product?.name || item.productName}</div>
                        <div className="text-xs text-gray-500">{product?.category || '-'}</div>
                      </td>
                      <td className="px-3 py-2 text-center">
                        <div>{item.originalQuantity} أساسي</div>
                        {item.originalSubQuantity > 0 && (
                          <div className="text-xs text-gray-500">{item.originalSubQuantity} فرعي</div>
                        )}
                      </td>
                      <td className="px-3 py-2 text-center">
                        <span className="px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-semibold">
                          {item.returnedQty}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-center">
                        <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                          item.availableQty > 0 ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                        }`}>
                          {item.availableQty}
                        </span>
                      </td>
                      <td className="px-3 py-2">
                        {item.selected && (
                          <div className="flex gap-1 justify-center">
                            <input
                              type="number"
                              value={item.returnQuantity}
                              onChange={(e) => handleQuantityChange(index, 'returnQuantity', e.target.value)}
                              className="w-12 px-1 py-1 text-xs text-center border border-gray-300 rounded"
                              min="0"
                              max={item.availableQty}
                              placeholder="أساسي"
                            />
                            {item.originalSubQuantity > 0 && (
                              <input
                                type="number"
                                value={item.returnSubQuantity}
                                onChange={(e) => handleQuantityChange(index, 'returnSubQuantity', e.target.value)}
                                className="w-12 px-1 py-1 text-xs text-center border border-gray-300 rounded"
                                min="0"
                                max={item.availableQty}
                                placeholder="فرعي"
                              />
                            )}
                          </div>
                        )}
                      </td>
                      <td className="px-3 py-2 text-center font-semibold text-red-600">
                        {item.selected ? returnAmount.toFixed(2) : '0.00'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* سبب الإرجاع والملاحظات */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                سبب الإرجاع <span className="text-red-500">*</span>
              </label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">اختر السبب...</option>
                <option value="defective">منتج معيب</option>
                <option value="damaged">منتج تالف</option>
                <option value="wrong_item">منتج خاطئ</option>
                <option value="expired">منتج منتهي الصلاحية</option>
                <option value="excess">زيادة في الكمية</option>
                <option value="other">أخرى</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ملاحظات إضافية</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows="2"
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="أدخل ملاحظات إضافية..."
              />
            </div>
          </div>
        </div>

        {/* ملخص الإرجاع */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-600">عدد المنتجات</p>
              <p className="text-2xl font-bold text-blue-600">
                {returnItems.filter(i => i.selected).length}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">إجمالي المرتجع</p>
              <p className="text-2xl font-bold text-red-600">
                {formatCurrency(calculateTotalReturn(), currentCurrency)}
              </p>
            </div>
          </div>
        </div>

        {/* أزرار الحفظ */}
        <div className="flex gap-2 justify-end">
          <button
            type="button"
            onClick={() => navigate('/purchases/manage')}
            className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-lg transition-colors"
          >
            إلغاء
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition-colors"
          >
            <FaUndo /> تنفيذ الإرجاع
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewPurchaseReturn;
