// ======================================
// صفحة الجرد والتقييم
// ======================================

import React from 'react';
import AssetInventory from '../../components/FixedAssets/AssetInventory';

const AssetInventoryPage = () => {
  return <AssetInventory />;
};

export default AssetInventoryPage;