// ======================================
// صفحة إدارة الإهلاك
// ======================================

import React from 'react';
import DepreciationManagement from '../../components/FixedAssets/DepreciationManagement';

const DepreciationManagementPage = () => {
  return <DepreciationManagement />;
};

export default DepreciationManagementPage;