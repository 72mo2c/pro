// ======================================
// صفحة جدولة الصيانة
// ======================================

import React from 'react';
import MaintenanceScheduling from '../../components/FixedAssets/MaintenanceScheduling';

const MaintenanceSchedulingPage = () => {
  return <MaintenanceScheduling />;
};

export default MaintenanceSchedulingPage;