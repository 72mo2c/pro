// ======================================
// صفحة التصرف في الأصول
// ======================================

import React from 'react';
import AssetDisposal from '../../components/FixedAssets/AssetDisposal';

const AssetDisposalPage = () => {
  return <AssetDisposal />;
};

export default AssetDisposalPage;