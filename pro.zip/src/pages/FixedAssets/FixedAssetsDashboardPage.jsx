// ======================================
// صفحة لوحة التحكم للأصول الثابتة
// ======================================

import React from 'react';
import FixedAssetsDashboard from '../../components/FixedAssets/FixedAssetsDashboard';

const FixedAssetsDashboardPage = () => {
  return <FixedAssetsDashboard />;
};

export default FixedAssetsDashboardPage;